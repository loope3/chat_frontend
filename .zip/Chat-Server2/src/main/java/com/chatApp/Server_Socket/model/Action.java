package com.chatApp.Server_Socket.model;

public enum Action {
    JOINED, LEFT, COMMENTED, NEW_MESSAGE, NEW_PRIVATE_MESSAGE
}
