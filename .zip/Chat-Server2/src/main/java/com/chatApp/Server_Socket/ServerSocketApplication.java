package com.chatApp.Server_Socket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServerSocketApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerSocketApplication.class, args);
		System.out.println("hello world, this will be our socket server program");
		System.out.println("this is a branch");





	}

}
