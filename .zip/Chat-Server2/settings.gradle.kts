rootProject.name = "Chat-Server2"
println("hello world test test test initialization phase")